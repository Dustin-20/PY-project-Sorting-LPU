import time
import random

cmp = 0
TYPE = 0


def algochooser(numbers, paint, label_comparison, something, TYPE_OF_DRAW, speed):
    global cmp, TYPE
    TYPE = TYPE_OF_DRAW

    if something == "Shell Sort":
        label_comparison.configure(text="No. of comparisons: 0")
        shellsort(numbers, paint, label_comparison, speed)
        if TYPE == 0:
            paint(["lawn green"] * len(numbers))
        cmp = 0

    elif something == "Radix Sort":
        label_comparison.configure(text="No. of comparisons: 0")
        radixsort(numbers, paint, speed)
        if TYPE == 0:
            paint(["lawn green"] * len(numbers))
        cmp = 0



def shellsort(number, paint, label_comparison, speed):
    global cmp, TYPE
    colors = []
    length = len(number)
    gap = length // 2
    while gap > 0:
        for x_sort in range(gap, length):
            j = x_sort - gap
            if TYPE == 0:
                colors = ["#cc0000" if xy == j + gap or xy ==
                                       j else "antique white" for xy in range(len(number))]
            else:
                colors = [((int)(x * 360) / 950) for x in number]
            paint(colors)
            while j >= 0:
                if (number[j + gap] < number[j]):
                    number[j + gap], number[j] = number[j], number[j + gap]
                else:
                    break
                cmp += 1
                if TYPE == 0:
                    colors = ["#cc0000" if xy == j + gap or xy ==
                                           j else "antique white" for xy in range(len(number))]
                else:
                    colors = [((int)(x * 360) / 950) for x in number]
                paint(colors)
                label_comparison.configure(text="No. of comparisons: " + str(cmp))
                # --------------------------------------------------------------------------------------------------
                j -= gap
            time.sleep(1 / speed)
        gap //= 2


def countsort(number, exp, paint):
    global TYPE
    colors = []
    count = [0] * 10
    temp = [0] * len(number)
    for x in range(len(number)):
        count[(number[x] // exp) % 10] += 1

    for y in range(1, len(count)):
        count[y] += count[y - 1]
    for z in range(len(number) - 1, -1, -1):
        index = count[(number[z] // exp) % 10]
        temp[index - 1] = number[z]
        count[(number[z] // exp) % 10] -= 1
    for w in range(len(temp)):
        number[w] = temp[w]
    if TYPE == 0:
        colors = ["antique white" for h in number]
    else:
        colors = [((int)(x * 360) / 950) for x in number]
    paint(colors)


def radixsort(number, paint, speed):
    global TYPE
    colors = []
    maximum = max(number)
    exp = 1
    while (maximum // exp >= 1):
        countsort(number, exp, paint)
        if TYPE == 0:
            colors = ["antique white" for h in number]
        else:
            colors = [((int)(x * 360) / 950) for x in number]
        paint(colors)
        time.sleep(1 / speed)
        exp *= 10
